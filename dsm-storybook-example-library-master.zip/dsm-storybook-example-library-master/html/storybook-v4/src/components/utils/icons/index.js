import flagIcon from './flag.svg';
import warnIcon from './warn.svg';
import checkmarkIcon from './check-circle.svg';
import errorIcon from './close-circle.svg';
import infoIcon from './info-circle.svg';
import closeIcon from './close.svg';
import chevronRightIcon from './chevron-right.svg';

export { flagIcon, warnIcon, checkmarkIcon, errorIcon, infoIcon, closeIcon, chevronRightIcon };
